﻿function Get-InstallerStepDefinitions([string]$Mode='install') {
    if($Mode -eq 'update'){return @(@('files','Verifica e preparazione del pacchetto'),@('dependencies','Librerie del nuovo pacchetto'),@('apply','Aggiornamento dei file di DOMIA'),@('start','Riavvio e verifica di DOMIA'))}
    return @(
        @('files','Preparazione di DOMIA'),@('node','Ambiente di esecuzione'),@('dependencies','Librerie di DOMIA'),
        @('ollama','Installazione e avvio di Ollama'),@('llama','Modello della chat'),@('gemma','Analisi delle immagini'),
        @('ocr','Lettura di testi e scansioni'),@('voice','LFM3: ascolto e parlato'),@('sd','Modello per generare immagini'),
        @('windows','Componenti Windows'),@('gpu','Preparazione e prova delle immagini'),
        @('https','Connessione sicura'),@('start','Collegamenti e avvio di DOMIA')
    )
}
function Initialize-InstallerProgress([string]$JobPath,[string]$Mode='install') {
    $script:progressFile = Join-Path (Split-Path -Parent $JobPath) 'progress.json'
    $script:installProgress = @{state='running';current='';message='Preparazione';percent=$null;download=$null;totalBytes=0;steps=@();log='';error=''}
    $script:installProgress.mode=$Mode
    foreach($entry in (Get-InstallerStepDefinitions $Mode)){ $script:installProgress.steps += @{id=$entry[0];title=$entry[1];state='pending';percent=$null} }
    Publish-InstallerProgress
}
function Publish-InstallerProgress {
    if (!$script:progressFile) { return }
    $temp = $script:progressFile + '.tmp'
    [IO.File]::WriteAllText($temp, ($script:installProgress | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
    if (Test-Path -LiteralPath $script:progressFile) { [IO.File]::Replace($temp,$script:progressFile,[NullString]::Value) }
    else { [IO.File]::Move($temp,$script:progressFile) }
}
function Set-InstallerStep([string]$Id,[string]$Message) {
    if (!$script:progressFile) { return }
    foreach ($step in $script:installProgress.steps) {
        if ($step.state -eq 'running') { $step.state='done';$step.percent=100 }
        if ($step.id -eq $Id) { $step.state='running';$step.percent=$null }
    }
    $script:installProgress.current=$Id
    Set-InstallerActivity $Message
}
function Set-InstallerActivity([string]$Message,$Percent=$null,[string]$DownloadPath='',[long]$TotalBytes=0) {
    if (!$script:progressFile) { return }
    $script:installProgress.message=$Message;$script:installProgress.percent=$Percent
    $script:installProgress.download=$DownloadPath;$script:installProgress.totalBytes=$TotalBytes
    foreach ($step in $script:installProgress.steps) { if ($step.id -eq $script:installProgress.current) { $step.percent=$Percent } }
    Publish-InstallerProgress
}
function Complete-InstallerProgress([bool]$Success,[string]$Message) {
    if (!$script:progressFile) { return }
    $script:installProgress.state = if ($Success) { 'done' } else { 'error' }
    foreach ($step in $script:installProgress.steps) { if ($step.state -eq 'running') { $step.state=if($Success){'done'}else{'error'};$step.percent=if($Success){100}else{$null} } }
    $script:installProgress.download='';$script:installProgress.message=$Message
    if (!$Success) { $script:installProgress.error=$Message }
    Publish-InstallerProgress
}
function Install-OllamaModel([string]$Model,[string]$Executable,[string]$Endpoint='http://127.0.0.1:11435') {
    if (!$script:progressFile) { & $Executable pull $Model;if($LASTEXITCODE -ne 0){throw "Download modello fallito: $Model"};return }
    $request = [Net.HttpWebRequest]::Create($Endpoint.TrimEnd('/')+'/api/pull')
    $request.Method='POST';$request.ContentType='application/json';$request.Timeout=120000;$request.ReadWriteTimeout=300000
    $bytes=[Text.Encoding]::UTF8.GetBytes((@{model=$Model;stream=$true}|ConvertTo-Json -Compress))
    $request.ContentLength=$bytes.Length;$stream=$request.GetRequestStream()
    try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
    $response=$null;$reader=$null;$success=$false
    try {
        $response=$request.GetResponse();$reader=[IO.StreamReader]::new($response.GetResponseStream());$lastUpdate=[DateTime]::MinValue
        while (($line=$reader.ReadLine()) -ne $null) {
            $item=$line|ConvertFrom-Json
            if($item.error){throw "Download modello $Model : $($item.error)"}
            if($item.status -eq 'success'){$success=$true}
            if(([DateTime]::UtcNow-$lastUpdate).TotalMilliseconds -ge 300 -or $success){
                $percent=$null;$message="Preparazione di $Model..."
                if($item.total -gt 0){$percent=[Math]::Min(100,[int](100*[double]$item.completed/[double]$item.total));$message="Download di $Model : $([Math]::Round($item.completed/1GB,2)) / $([Math]::Round($item.total/1GB,2)) GB (componente corrente)"}
                elseif($item.status -match 'verif|sha256'){$message="Verifica dei file di $Model..."}
                Set-InstallerActivity $message $percent;$lastUpdate=[DateTime]::UtcNow
            }
        }
        if(!$success){throw "Download modello incompleto: $Model"}
    } finally { if($reader){$reader.Dispose()};if($response){$response.Dispose()} }
}
