$ErrorActionPreference = 'Stop'
$voiceRoot = Split-Path -Parent $PSScriptRoot
$voiceNodePath = $null
$voiceInstallConfig = Join-Path $voiceRoot 'runtime\install.json'
if (Test-Path -LiteralPath $voiceInstallConfig) { $voiceNodePath = (Get-Content -LiteralPath $voiceInstallConfig -Raw | ConvertFrom-Json).nodePath }
if (!$voiceNodePath) { $voiceNodePath = (Get-Command node.exe -ErrorAction Stop).Source }
& $voiceNodePath (Join-Path $voiceRoot 'scripts\setup-lfm-audio.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Preparazione LFM3-Audio non riuscita' }
