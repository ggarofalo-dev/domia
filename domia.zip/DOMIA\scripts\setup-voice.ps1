﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$voiceRoot = Split-Path -Parent $PSScriptRoot
$modelsFolder = Join-Path $voiceRoot 'models'
$foldersFile = Join-Path $voiceRoot 'data\model-folders.json'
if (Test-Path -LiteralPath $foldersFile) { $modelsFolder = (Get-Content -LiteralPath $foldersFile -Raw | ConvertFrom-Json).local }
New-Item -ItemType Directory -Path $modelsFolder -Force | Out-Null
$voiceModel = Join-Path $modelsFolder 'ggml-base.bin'
$voiceNodePath = $null
$voiceInstallConfig = Join-Path $voiceRoot 'runtime\install.json'
if (Test-Path -LiteralPath $voiceInstallConfig) { $voiceNodePath = (Get-Content -LiteralPath $voiceInstallConfig -Raw | ConvertFrom-Json).nodePath }
if (!$voiceNodePath -or !(Test-Path -LiteralPath $voiceNodePath)) {
    $voiceNode = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($voiceNode) { $voiceNodePath = $voiceNode.Source }
    else { $voiceNodePath = Get-ChildItem -LiteralPath (Join-Path $voiceRoot 'runtime') -Directory -Filter 'node-*-win-x64' | ForEach-Object { Join-Path $_.FullName 'node.exe' } | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1 }
}
if (!$voiceNodePath) { throw 'Node non trovato: ripara il runtime con installer DOMIA.' }
& $voiceNodePath (Join-Path $voiceRoot 'scripts\setup-whisper.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Preparazione Whisper 1.9.5 non riuscita' }
if (-not (Test-Path -LiteralPath $voiceModel)) { Invoke-WebRequest -UseBasicParsing -Uri 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin' -OutFile $voiceModel }
if ((Get-FileHash -LiteralPath $voiceModel -Algorithm SHA256).Hash.ToLowerInvariant() -ne '60ed5bc3dd14eea856493d334349b405782ddcaf0028d4b5df4088345fba2efe') { throw 'Checksum del modello Whisper non valido' }
Write-Output 'Whisper v1.9.5 e modello base multilingue verificati'
