﻿param([Parameter(Mandatory=$true)][string]$NodePath,[string]$Redist,[Parameter(Mandatory=$true)][string]$Result,[switch]$VoiceReady)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'windows-components.ps1')
try {
    if (-not (Test-DomiaVcRuntime)) {
        if (!$Redist -or !(Test-Path -LiteralPath $Redist)) { throw 'Visual C++ richiede installazione. Ripetere la procedura per preparare il download.' }
        $p = Start-Process -FilePath $Redist -ArgumentList '/install /quiet /norestart' -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -notin @(0,1638,3010)) { throw "Visual C++: codice $($p.ExitCode)" }
    }
    $rule = 'DOMIA Local - Private LAN'
    $existing = Get-NetFirewallRule -Name $rule -ErrorAction SilentlyContinue
    if ($existing) { $existing | Remove-NetFirewallRule }
    New-NetFirewallRule -Name $rule -DisplayName 'DOMIA - rete privata locale' -Direction Inbound -Action Allow -Profile Private -RemoteAddress LocalSubnet -Protocol TCP -LocalPort 3310,3312 -Program $NodePath | Out-Null
    Ensure-DomiaItalianSpeech -VoiceReady:$VoiceReady
    Set-Content -LiteralPath $Result -Value 'OK' -Encoding ASCII
} catch {
    Set-Content -LiteralPath $Result -Value $_.Exception.Message -Encoding UTF8
    exit 1
}
