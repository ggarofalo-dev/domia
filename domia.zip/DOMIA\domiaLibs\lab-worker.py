"""DOMIA host media worker. NDJSON IPC, local frames, half-duplex audio.
No camera frames or audio recordings are written to disk.
"""
import sys, json, threading, time, queue, hashlib, base64, io, wave, os, ctypes
import numpy as np
import cv2
import sounddevice as sd

out_lock = threading.Lock()
def emit(value):
    with out_lock:
        print(json.dumps(value, ensure_ascii=True), flush=True)

def key(kind, *parts):
    return kind + ':' + hashlib.sha256(json.dumps(parts, ensure_ascii=True).encode()).hexdigest()[:24]

def inventory():
    from pygrabber.dshow_graph import FilterGraph
    names = FilterGraph().get_input_devices()
    cams = [dict(id=key('camera', name), name=name, index=i, ambiguous=names.count(name)>1) for i,name in enumerate(names)]
    hosts = sd.query_hostapis()
    devices = sd.query_devices()
    def audio(direction):
        rows=[]
        for i,d in enumerate(devices):
            if d['max_'+direction+'_channels'] < 1: continue
            host=hosts[d['hostapi']]['name']
            rows.append(dict(id=key(direction,d['name'],host),name=d['name']+' ('+host+')',index=i,rate=int(d['default_samplerate']),channels=min(2,d['max_output_channels']) if direction=='output' else 1,ambiguous=False))
        for r in rows: r['ambiguous']=sum(x['id']==r['id'] for x in rows)>1
        return rows
    return dict(cameras=cams,microphones=audio('input'),speakers=audio('output'))

def selected(rows, ident):
    matches=[x for x in rows if x['id']==ident]
    if len(matches)!=1 or matches[0]['ambiguous']:
        raise RuntimeError('Dispositivo assente o nome ambiguo: seleziona un dispositivo univoco e salva nuovamente.')
    return matches[0]

if '--inventory' in sys.argv:
    try: emit(dict(inventory=inventory()))
    except Exception as e: emit(dict(error=str(e))); sys.exit(1)
    sys.exit(0)

commands=queue.Queue()
cancel=threading.Event()
stop=threading.Event()
frame_lock=threading.Lock()
last_frame=None
def stdin_reader():
    try:
        for line in sys.stdin:
            try:
                cmd=json.loads(line)
                if cmd.get('op') in ('cancel','stop'): cancel.set()
                if cmd.get('op')=='stop': stop.set(); break
                if cmd.get('op')!='cancel': commands.put(cmd)
            except Exception as e: emit(dict(error=str(e)))
    finally: stop.set(); cancel.set()

def record(device):
    rate=device['rate']; blocks=queue.Queue(maxsize=256)
    def callback(data,frames,timing,status):
        try: blocks.put_nowait(data.copy())
        except queue.Full: pass
    parts=[]; start=time.monotonic(); heard=False; silence=start
    with sd.InputStream(device=device['index'],samplerate=rate,channels=1,dtype='float32',blocksize=max(256,rate//20),callback=callback):
        while not cancel.is_set() and not stop.is_set():
            try: b=blocks.get(timeout=.1)
            except queue.Empty:
                if time.monotonic()-start>15: break
                continue
            parts.append(b[:,0]); now=time.monotonic()
            if float(np.sqrt(np.mean(b*b)))>.012: heard=True; silence=now
            if heard and now-silence>1.2 or now-start>15 or not heard and now-start>8: break
    if cancel.is_set() or not heard: return ''
    values=np.concatenate(parts); values=np.interp(np.arange(0,len(values),rate/16000),np.arange(len(values)),values)
    wav=io.BytesIO()
    with wave.open(wav,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes((np.clip(values,-1,1)*32767).astype('<i2').tobytes())
    return base64.b64encode(wav.getvalue()).decode()

def playback(audio,device):
    with wave.open(io.BytesIO(base64.b64decode(audio)),'rb') as w:
        if w.getsampwidth()!=2: raise RuntimeError('Sintesi: formato PCM16 richiesto')
        rate=w.getframerate(); channels=w.getnchannels(); data=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,channels)
    # Resample for the selected output rather than assuming all devices accept the TTS rate.
    target=device['rate']
    if rate!=target:
        positions=np.arange(0,len(data),rate/target)
        data=np.stack([np.interp(positions,np.arange(len(data)),data[:,c]) for c in range(channels)],axis=1)
    output_channels=device.get('channels',channels)
    if channels==1 and output_channels==2: data=np.repeat(data,2,axis=1)
    elif channels==2 and output_channels==1: data=np.mean(data,axis=1,keepdims=True)
    elif channels!=output_channels: raise RuntimeError('Canali uscita audio non supportati')
    # Send interleaved PCM16 bytes, using the physical output's channel count.
    # Mono speech on a stereo Windows endpoint must be duplicated, not reinterpreted.
    data=np.ascontiguousarray(np.clip(np.rint(data),-32768,32767),dtype='<i2')
    with sd.RawOutputStream(device=device['index'],samplerate=target,channels=output_channels,dtype='int16',latency='high') as stream:
        for offset in range(0,len(data),max(256,target//20)):
            if cancel.is_set() or stop.is_set(): break
            stream.write(data[offset:offset+max(256,target//20)].tobytes())

def audio_loop(mic,speaker):
    while not stop.is_set():
        try: cmd=commands.get(timeout=.2)
        except queue.Empty: continue
        cancel.clear()
        try:
            op=cmd.get('op'); result={}
            if op=='listen': result['audio']=record(mic)
            elif op=='play': playback(cmd['audio'],speaker)
            elif op=='preview':
                with frame_lock:
                    if last_frame is None: raise RuntimeError('Nessuna immagine disponibile')
                    ok,jpg=cv2.imencode('.jpg',last_frame,[cv2.IMWRITE_JPEG_QUALITY,65])
                if not ok: raise RuntimeError('Immagine non disponibile')
                result['image']=base64.b64encode(jpg).decode()
            else: raise RuntimeError('Comando non valido')
            emit(dict(reply=cmd['id'],**result))
        except Exception as e:
            emit(dict(reply=cmd.get('id'),error=str(e)))
            if cmd.get('op') in ('listen','play'):
                emit(dict(error='Dispositivo audio non disponibile: '+str(e))); stop.set()

camera=None
probe='--probe' in sys.argv
try:
    cfg=json.loads(sys.stdin.readline())
    devices=inventory(); cam=selected(devices['cameras'],cfg['camera']); mic=selected(devices['microphones'],cfg['microphone']); speaker=selected(devices['speakers'],cfg['speaker'])
    sd.check_input_settings(device=mic['index'],samplerate=mic['rate'],channels=1,dtype='float32')
    sd.check_output_settings(device=speaker['index'],samplerate=speaker['rate'],channels=speaker['channels'],dtype='int16')
    # Enumerated devices can still be disabled or occupied. Validate actual opening before ready.
    with sd.InputStream(device=mic['index'],samplerate=mic['rate'],channels=1,dtype='float32',callback=lambda data,n,t,s:None): pass
    with sd.RawOutputStream(device=speaker['index'],samplerate=speaker['rate'],channels=speaker['channels'],dtype='int16',latency='high'): pass
    models=cfg['models']
    detector=cv2.FaceDetectorYN.create(os.path.join(models,'face_detection_yunet_2023mar.onnx'),'',(640,480),.9,.3,5000)
    recognizer=cv2.FaceRecognizerSF.create(os.path.join(models,'face_recognition_sface_2021dec.onnx'),'')
    camera=cv2.VideoCapture(cam['index'],cv2.CAP_DSHOW)
    camera.set(cv2.CAP_PROP_FRAME_WIDTH,640); camera.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
    if not camera.isOpened(): raise RuntimeError('Webcam occupata o non disponibile')
    power=ctypes.windll.kernel32.SetThreadExecutionState
    power.argtypes=[ctypes.c_uint]; power.restype=ctypes.c_uint
    if cfg.get('keepAwake'):
        if not power(0x80000001): raise RuntimeError('Impossibile mantenere attivo il server')
    if not probe:
        threading.Thread(target=stdin_reader,daemon=True).start()
        threading.Thread(target=audio_loop,args=(mic,speaker),daemon=True).start()
    emit(dict(ready=True,keepAwake=bool(cfg.get('keepAwake'))))
    failures=0; frames_seen=0
    while not stop.is_set():
        ok,frame=camera.read()
        if not ok:
            failures+=1
            if failures>=5: raise RuntimeError('Webcam scollegata o acquisizione interrotta')
            time.sleep(.3); continue
        failures=0
        # Bound compute even for cameras ignoring the requested resolution.
        if frame.shape[1]>800: frame=cv2.resize(frame,(800,int(frame.shape[0]*800/frame.shape[1])))
        with frame_lock: last_frame=frame
        detector.setInputSize((frame.shape[1],frame.shape[0])); _,faces=detector.detect(frame)
        count=0 if faces is None else len(faces)
        event=dict(faces=count)
        if count==1:
            aligned=recognizer.alignCrop(frame,faces[0]); vector=recognizer.feature(aligned).flatten(); vector=vector/np.linalg.norm(vector)
            if not probe: event['embedding']=vector.tolist()
        emit(event); stop.wait(.5)
        if probe:
            frames_seen+=1
            if frames_seen>=4:
                # Exercise actual input callback and output stream without retaining recordings.
                captured=[]
                with sd.InputStream(device=mic['index'],samplerate=mic['rate'],channels=1,dtype='float32',callback=lambda data,n,t,s:captured.append(n)):
                    time.sleep(.5)
                if not captured: raise RuntimeError('Il microfono non restituisce campioni')
                silence=io.BytesIO()
                with wave.open(silence,'wb') as wav:
                    wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(16000); wav.writeframes(bytes(3200))
                playback(base64.b64encode(silence.getvalue()).decode(),speaker)
                emit(dict(probe=True,camera=True,microphone=True,speaker=True)); stop.set()
except Exception as e:
    emit(dict(error=str(e))); sys.exit(1)
finally:
    stop.set(); cancel.set()
    if camera is not None: camera.release()
    if sys.platform=='win32': ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
