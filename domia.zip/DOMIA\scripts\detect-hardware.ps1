﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object {
    @{name=$_.Name;memoryBytes=[double]$_.AdapterRAM;memorySource='Windows estimate'}
})
@{gpus=$gpus} | ConvertTo-Json -Depth 4 -Compress
