﻿param([string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'DOMIA'),[switch]$ValidateOnly,[string]$ModelsRoot,[string]$OllamaModelsRoot,[string]$GuiJob,[Nullable[bool]]$AutoStart=$null)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$source = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'progress.ps1')
. (Join-Path $PSScriptRoot 'existing.ps1')
. (Join-Path $PSScriptRoot 'startup.ps1')
. (Join-Path $PSScriptRoot 'windows-components.ps1')
if (!$PSBoundParameters.ContainsKey('InstallRoot')) { $found=Find-ExistingDomia $InstallRoot;if($found){$InstallRoot=$found.root} }
$existing=Get-ExistingDomia $InstallRoot
$mode=if($existing){'update'}else{'install'}
if ($GuiJob) { Initialize-InstallerProgress $GuiJob $mode; Set-InstallerStep 'files' 'Verifico il pacchetto DOMIA...' }
function Verify-Package {
    $manifest = Get-Content (Join-Path $source 'manifest.json') -Raw | ConvertFrom-Json
    foreach ($file in $manifest.files) {
        $path = [IO.Path]::GetFullPath((Join-Path $source $file.path))
        if (-not $path.StartsWith($source + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Percorso pacchetto non valido' }
        if (-not (Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256) { throw "Pacchetto corrotto: $($file.path)" }
    }
}
function Download([string]$Url,[string]$Path,[string]$Hash) {
    if ((Test-Path -LiteralPath $Path) -and (!$Hash -or (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -eq $Hash)) { return }
    Write-Host "Download: $([IO.Path]::GetFileName($Path))"
    New-Item -ItemType Directory -Path (Split-Path $Path) -Force | Out-Null
    $partial = "$Path.part"
    $totalBytes = 0
    if ($GuiJob) {
        try { $head = Invoke-WebRequest -UseBasicParsing -Method Head -Uri $Url -TimeoutSec 15; $totalBytes = [long]$head.Headers['Content-Length'] } catch { }
    }
    Set-InstallerActivity ('Scarico ' + [IO.Path]::GetFileName($Path) + '...') $null $partial $totalBytes
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
        & curl.exe --fail --location --retry 4 --retry-delay 3 --connect-timeout 30 --continue-at - --output $partial $Url
        if ($LASTEXITCODE -eq 33 -or $LASTEXITCODE -eq 22) {
            & curl.exe --fail --location --retry 4 --output $partial $Url
        }
        if ($LASTEXITCODE -ne 0) { throw "Download fallito: $Url" }
    } else { Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $partial }
    Set-InstallerActivity ('Verifico ' + [IO.Path]::GetFileName($Path) + '...')
    if ($Hash -and (Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ne $Hash) {
        Remove-Item -LiteralPath $partial
        throw "Checksum non valido: $Url. Ripetere installa.bat."
    }
    Move-Item -LiteralPath $partial -Destination $Path -Force
    Set-InstallerActivity 'Download completato. Proseguo con la preparazione...'
}
function Signed-By([string]$Path,[string]$Publisher) {
    $sig = Get-AuthenticodeSignature -LiteralPath $Path
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch $Publisher) { throw "Firma digitale non valida: $Path" }
}
function Run-Node([string[]]$Arguments) {
    & $script:nodePath @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Componente Node fallito: $($Arguments -join ' ')" }
}
Verify-Package
if ($ValidateOnly) { Write-Host 'Pacchetto verificato. Nessuna modifica al sistema.'; exit 0 }
if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { throw 'Questo pacchetto richiede Windows x64 (Intel/AMD).' }
. (Join-Path $PSScriptRoot 'consent.ps1')
$termsPath = Join-Path $PSScriptRoot 'CONDIZIONI.txt'
if ($GuiJob) {
    $guiConfig = Get-Content -LiteralPath $GuiJob -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($guiConfig.accepted -ne $true -or $guiConfig.termsSha256 -ne (Get-FileHash -LiteralPath $termsPath).Hash) { throw 'Condizioni non accettate o modificate. Riavviare la procedura grafico.' }
} elseif (-not (Show-InstallerConditions $termsPath)) { Write-Host 'Installazione annullata: condizioni non accettate. Nessun componente installato.'; exit 2 }
$consentHash = (Get-FileHash -LiteralPath $termsPath -Algorithm SHA256).Hash.ToLowerInvariant()
$consentAt = [DateTime]::UtcNow.ToString('o')
if($GuiJob -and $null -ne $guiConfig.autoStart){$AutoStart=[bool]$guiConfig.autoStart}
if($null -eq $AutoStart){
    if($existing){$AutoStart=Get-DomiaAutoStart $InstallRoot}
    else{$answer=Read-Host 'Avviare DOMIA automaticamente all accesso a Windows? [s/N]';$AutoStart=$answer.Trim() -match '^(s|si|y|yes)$'}
}
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
@{accepted=$true;acceptedAt=$consentAt;termsSha256=$consentHash;version=(Get-Content (Join-Path $source 'package.json') -Raw | ConvertFrom-Json).version} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $InstallRoot 'installation-consent.json') -Encoding UTF8
if ($existing) {
    . (Join-Path $PSScriptRoot 'update.ps1')
    try { Update-ExistingDomia $source $InstallRoot -AutoStart $AutoStart }
    catch { Complete-InstallerProgress $false $_.Exception.Message;Write-Error $_.Exception.Message -ErrorAction Continue;exit 1 }
    exit 0
}
Start-Transcript -Path (Join-Path $InstallRoot 'installation.log') -Append | Out-Null
if ($GuiJob) { $script:installProgress.log = Join-Path $InstallRoot 'installation.log'; Publish-InstallerProgress }
try {
    Write-Host 'DOMIA - Installazione automatica. Il primo download puo richiedere tempo.'
    # Stop only the supervisor and child server belonging to this installation.
    $statusFile = Join-Path $InstallRoot 'data\service\status.json'
    $existingHealth = $null
    try { $existingHealth = Invoke-RestMethod 'http://127.0.0.1:3310/api/health' -TimeoutSec 2 } catch {}
    if ($existingHealth -and !(Test-Path $statusFile)) { throw 'La porta 3310 e gia occupata. Arrestare l altra installazione di DOMIA prima di continuare.' }
    if (Test-Path $statusFile) {
        $state = Get-Content $statusFile -Raw | ConvertFrom-Json
        foreach ($processId in @($state.supervisorPid,$state.appPid)) {
            if ($processId) {
                $owned = Get-CimInstance Win32_Process -Filter "ProcessId=$processId"
                if ($owned -and $owned.CommandLine -and ($owned.CommandLine.Contains($InstallRoot) -or ($owned.ParentProcessId -eq $state.supervisorPid -and $owned.CommandLine -match '(?:src|domiaLibs)[/\\]server.mjs'))) { Stop-Process -Id $processId -Force }
            }
        }
    }
    if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($InstallRoot)) {
        foreach ($name in @('src','domiaLibs','public','scripts','installer','package.json','package-lock.json','start.cmd','config')) {
            if (Test-Path -LiteralPath (Join-Path $source $name)) { Copy-Item -LiteralPath (Join-Path $source $name) -Destination $InstallRoot -Recurse -Force }
        }
    }
    Set-Location $InstallRoot
    $foldersFile = Join-Path $InstallRoot 'data\model-folders.json'
    $previousFolders = $null
    if (Test-Path -LiteralPath $foldersFile) { $previousFolders = Get-Content -LiteralPath $foldersFile -Raw | ConvertFrom-Json }
    if (!$ModelsRoot) {
        $defaultModels = Join-Path $InstallRoot 'models'
        if ($previousFolders.local) { $defaultModels = $previousFolders.local }
        $chosen = Read-Host "Cartella modelli immagini, audio, video e OCR [Invio: $defaultModels]"
        $ModelsRoot = if ($chosen.Trim()) { $chosen.Trim() } else { $defaultModels }
    }
    if (!$OllamaModelsRoot) {
        $defaultOllama = Join-Path $InstallRoot 'models-ollama'
        if ($previousFolders.ollama) { $defaultOllama = $previousFolders.ollama }
        $chosen = Read-Host "Cartella modelli Ollama [Invio: $defaultOllama]"
        $OllamaModelsRoot = if ($chosen.Trim()) { $chosen.Trim() } else { $defaultOllama }
    }
    Write-Host 'I modelli precedenti restano nelle vecchie cartelle. Per riutilizzarli copiarli nella nuova destinazione mantenendo le sottocartelle.'
    New-Item -ItemType Directory -Path 'runtime\downloads','models' -Force | Out-Null
    Set-InstallerStep 'node' 'Preparo il motore di esecuzione...'
    $nodePath = $null
    $candidate = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($candidate) {
        $version = & $candidate.Source -p 'process.versions.node'
        if ($LASTEXITCODE -eq 0 -and [version]$version -ge [version]'24.0.0' -and (Test-Path (Join-Path (Split-Path $candidate.Source) 'node_modules\npm\bin\npm-cli.js'))) { $nodePath = $candidate.Source }
    }
    if (!$nodePath) {
        $nodePath = Join-Path $InstallRoot 'runtime\node-v24.21.0-win-x64\node.exe'
        if (!(Test-Path $nodePath)) {
            Download 'https://nodejs.org/dist/v24.21.0/node-v24.21.0-win-x64.zip' "$InstallRoot\runtime\downloads\node.zip" '158f7685b44de51f6c0df1d153526cbcd3e1bc739a8dfc607721cef75de9e541'
            Expand-Archive -LiteralPath 'runtime\downloads\node.zip' -DestinationPath 'runtime' -Force
        }
    }
    Run-Node -Arguments @('scripts/configure-model-folders.mjs',$ModelsRoot,$OllamaModelsRoot)
    $ModelsRoot = [IO.Path]::GetFullPath($ModelsRoot)
    $OllamaModelsRoot = [IO.Path]::GetFullPath($OllamaModelsRoot)
    $env:OLLAMA_MODELS = $OllamaModelsRoot
    $env:PATH = (Split-Path $nodePath) + ';' + $env:PATH
    $npm = Join-Path (Split-Path $nodePath) 'node_modules\npm\bin\npm-cli.js'
    Set-InstallerStep 'dependencies' 'Installo e verifico le librerie di DOMIA...'
    $lockHash = (Get-FileHash 'package-lock.json').Hash
    $stamp = 'runtime\dependencies.sha256'
    $depsOK = $false
    if ((Test-Path $stamp) -and (Get-Content $stamp) -eq $lockHash) {
        & $nodePath 'installer/verify-runtime.mjs'
        $depsOK = $LASTEXITCODE -eq 0
    }
    if (!$depsOK) {
        # Keep npm cache/logs in this installation, independent of the user's npm cache.
        $npmCache = Join-Path $InstallRoot 'runtime\npm-cache'
        Write-Host "Librerie npm: cache e log in $npmCache"
        try {
            Run-Node -Arguments @($npm,'ci','--omit=dev','--ignore-scripts','--no-audit','--no-fund','--cache',$npmCache,'--registry=https://registry.npmjs.org/','--offline=false','--prefer-online','--fetch-retries=4','--fetch-timeout=120000')
        } catch {
            throw "Download librerie npm fallito. Controllare connessione/proxy e il log in $npmCache\_logs. Ripetere installa.bat. Dettaglio: $($_.Exception.Message)"
        }
        Run-Node -Arguments @('installer/verify-runtime.mjs')
        Set-Content $stamp $lockHash -Encoding ASCII
    }
    Set-InstallerStep 'ollama' 'Preparo Ollama per i modelli locali...'
    . (Join-Path $PSScriptRoot 'ollama-processes.ps1')
    Run-Node -Arguments @('scripts/setup-ollama.mjs','--force','--prepare-only')
    $ollamaPath = Join-Path $InstallRoot 'runtime\ollama-0.40.13\ollama.exe'
    Stop-InstallerOllama $ollamaPath
    $env:OLLAMA_HOST = '127.0.0.1:11435'
    try { $null = Invoke-RestMethod 'http://127.0.0.1:11435/api/tags' -TimeoutSec 3 } catch {
        Start-Process -FilePath $ollamaPath -ArgumentList 'serve' -WindowStyle Hidden
    }
    Write-Host 'Attendo la risposta del server Ollama...'
    $ready = $false
    for ($i=0;$i -lt 60;$i++) {
        try { $tags = Invoke-RestMethod 'http://127.0.0.1:11435/api/tags' -TimeoutSec 2; $ready=$true; break } catch { Start-Sleep -Seconds 2 }
    }
    if (!$ready) { throw 'Ollama non risponde sulla porta 11435' }
    foreach ($model in @('llama3.2:latest','gemma3:4b')) {
        $stepId = if ($model -eq 'llama3.2:latest') { 'llama' } else { 'gemma' }
        Set-InstallerStep $stepId ('Preparo il modello ' + $model + '...')
        if ($tags.models.name -notcontains $model) {
            Write-Host "Modello: $model"
            Install-OllamaModel $model $ollamaPath
        }
    }
    Set-InstallerStep 'ocr' 'Preparo la lettura di immagini e scansioni...'
    Run-Node -Arguments @('scripts/setup-ocr.mjs')
    Set-InstallerStep 'voice' 'Preparo LFM3-Audio per ascolto e parlato...'
    Run-Node -Arguments @('scripts/setup-lfm-audio.mjs')
    Set-InstallerStep 'sd' 'Preparo il motore e il modello per generare immagini...'
    if (!(Test-Path 'runtime\sd\sd-cli.exe')) {
        Download 'https://github.com/leejet/stable-diffusion.cpp/releases/download/master-929-3f8527a/sd-master-3f8527a-bin-win-cpu-x64.zip' "$InstallRoot\runtime\downloads\sd.zip" '5e7caca2080321b25a12c1fa4175cb7d953f2b182309f8f73bfc9c725231d26c'
        Expand-Archive 'runtime\downloads\sd.zip' 'runtime\sd' -Force
    }
    Download 'https://huggingface.co/Comfy-Org/stable-diffusion-v1-5-archive/resolve/main/v1-5-pruned-emaonly-fp16.safetensors' "$ModelsRoot\sd15.safetensors" 'e9476a13728cd75d8279f6ec8bad753a66a1957ca375a1464dc63b37db6e3916'
    Set-InstallerStep 'windows' 'Preparo i componenti Windows. Potrebbe essere richiesto il consenso amministratore.'
    $redist = Get-DomiaRedistPackage "$InstallRoot\runtime\downloads\vc_redist.x64.exe"
    Write-Host 'Windows richiedera il consenso per firewall e runtime.'
    $result = "$InstallRoot\runtime\system-result.txt"
    if (Test-Path $result) { Remove-Item -LiteralPath $result }
    $args = '-NoProfile -ExecutionPolicy Bypass -File "' + "$InstallRoot\installer\system.ps1" + '" -NodePath "' + $nodePath + '" -Result "' + $result + '"'
    if ($redist) { $args += ' -Redist "' + $redist + '"' }
    $p = Start-Process powershell.exe -Verb RunAs -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
    if ($p.ExitCode -ne 0 -or !(Test-Path $result) -or (Get-Content $result -Raw).Trim() -ne 'OK') { throw "Configurazione Windows fallita. Consultare $result" }
    & "$InstallRoot\runtime\sd\sd-cli.exe" --help *> 'runtime\sd-check.log'
    if ($LASTEXITCODE -ne 0) { throw 'Motore immagini non avviabile. Consultare runtime\sd-check.log' }
    Set-Content (Join-Path $ModelsRoot 'sd15.ready') 'SD 1.5 fp16 verified; CPU runtime master-929-3f8527a' -Encoding ASCII
    @{nodePath=$nodePath;ollamaPath=$ollamaPath;autoStart=[bool]$AutoStart} | ConvertTo-Json | Set-Content 'runtime\install.json' -Encoding UTF8
    Write-Host 'Configurazione automatica immagini: rilevamento NVIDIA/AMD/Intel e prova del runtime compatibile.'
    Set-InstallerStep 'gpu' 'Rilevo la scheda video e provo il motore immagini. Questa fase può richiedere diversi GB e alcuni minuti...'
    Run-Node -Arguments @('scripts/configure-images.mjs')
    Set-InstallerStep 'https' 'Preparo la connessione sicura...'
    Run-Node -Arguments @('scripts/setup-https.mjs')
    Set-InstallerStep 'start' 'Preparo chat e ricerca semantica, creo i collegamenti e avvio DOMIA...'
    Run-Node -Arguments @('scripts/finalize-installer-setup.mjs')
    $background = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + "$InstallRoot\scripts\run-background.ps1" + '"'
    Set-DomiaStartup $InstallRoot ([bool]$AutoStart)
    Start-Process powershell.exe -ArgumentList $background -WindowStyle Hidden
    $healthy = $false
    for ($i=0;$i -lt 60;$i++) {
        try { $health = Invoke-RestMethod 'http://127.0.0.1:3310/api/health' -TimeoutSec 2; if ($health.app -eq 'domia') { $healthy=$true; break } } catch {}
        Start-Sleep -Seconds 2
    }
    if (!$healthy) { throw 'DOMIA non si avvia. Consultare data\service\supervisor.log' }
    Register-DomiaInstallation $InstallRoot
    Complete-InstallerProgress $true 'Installazione completata. DOMIA è pronto: apro la pagina nel browser.'
    Write-Host 'Installazione completata. Apertura DOMIA...'
    Start-Process 'http://localhost:3310'
} catch {
    Complete-InstallerProgress $false ($_.Exception.Message + ' Puoi consultare i dettagli con Apri log e ripetere la procedura con le stesse cartelle.')
    Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $InstallRoot\installation.log"
    exit 1
} finally { Stop-Transcript | Out-Null }

