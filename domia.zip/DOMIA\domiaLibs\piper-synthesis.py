"""Persistent UTF-8 protocol for DOMIA's private Piper runtime."""
import json
import sys
import wave
from piper import PiperVoice, SynthesisConfig

sys.stdin.reconfigure(encoding="utf-8")
sys.stdout.reconfigure(encoding="utf-8")
voice = PiperVoice.load(sys.argv[1], config_path=sys.argv[2])
rate_scale = float(sys.argv[3])
config = SynthesisConfig(
    length_scale=voice.config.length_scale * rate_scale,
    noise_scale=voice.config.noise_scale,
    noise_w_scale=voice.config.noise_w_scale,
)
for line in sys.stdin:
    request = json.loads(line)
    with wave.open(request["output_file"], "wb") as wav:
        voice.synthesize_wav(request["text"], wav, syn_config=config)
    print(request["output_file"], flush=True)
