﻿function Test-DomiaVcRuntime {
    $vc = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue
    if (!$vc -or $vc.Installed -ne 1 -or !$vc.Version) { return $false }
    try { return [version]$vc.Version.TrimStart('v') -ge [version]'14.42.0' } catch { return $false }
}

function Test-DomiaItalianSpeech {
    $speech = $null
    try {
        Add-Type -AssemblyName System.Speech -ErrorAction Stop
        $speech = New-Object System.Speech.Synthesis.SpeechSynthesizer
        return @($speech.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'it-*' }).Count -gt 0
    } catch { return $false } finally { if ($speech) { $speech.Dispose() } }
}

function Get-DomiaRedistPackage([string]$Destination) {
    if (Test-DomiaVcRuntime) { Write-Host 'Visual C++ x64 compatibile gia presente: nessun download.'; return '' }
    Download 'https://aka.ms/vc14/vc_redist.x64.exe' $Destination ''
    Signed-By $Destination 'Microsoft Corporation'
    return $Destination
}

function Enable-DomiaItalianDesktopVoices {
    $source = 'HKLM:\SOFTWARE\Microsoft\Speech_OneCore\Voices\Tokens'
    $target = 'HKLM:\SOFTWARE\Microsoft\Speech\Voices\Tokens'
    Get-ChildItem $source -ErrorAction SilentlyContinue | Where-Object PSChildName -Match 'ITIT' | ForEach-Object {
        if (-not (Test-Path (Join-Path $target $_.PSChildName))) { Copy-Item -LiteralPath $_.PSPath -Destination $target -Recurse }
    }
}

function Ensure-DomiaItalianSpeech([switch]$VoiceReady) {
    if ($VoiceReady) { Write-Host 'Voce italiana utilizzabile gia presente: nessun download.'; return }
    # Reuse machine-wide OneCore voices before requesting a Windows language download.
    Enable-DomiaItalianDesktopVoices
    if (Test-DomiaItalianSpeech) { Write-Host 'Voce italiana esistente resa disponibile: nessun download.'; return }
    $cap = Get-WindowsCapability -Online -Name 'Language.TextToSpeech~~~it-IT~0.0.1.0'
    if (!$cap) { throw 'Impossibile verificare il componente vocale italiano di Windows.' }
    if ($cap.State -ne 'Installed') { Add-WindowsCapability -Online -Name $cap.Name | Out-Null }
    Enable-DomiaItalianDesktopVoices
}
