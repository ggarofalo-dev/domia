﻿function Test-DomiaVcRuntime {
    $vc = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue
    if (!$vc -or $vc.Installed -ne 1 -or !$vc.Version) { return $false }
    try { return [version]$vc.Version.TrimStart('v') -ge [version]'14.42.0' } catch { return $false }
}

function Get-DomiaRedistPackage([string]$Destination) {
    if (Test-DomiaVcRuntime) { Write-Host 'Visual C++ x64 compatibile gia presente: nessun download.'; return '' }
    Download 'https://aka.ms/vc14/vc_redist.x64.exe' $Destination ''
    Signed-By $Destination 'Microsoft Corporation'
    return $Destination
}

