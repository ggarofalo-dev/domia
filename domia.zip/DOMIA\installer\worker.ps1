﻿param([Parameter(Mandatory=$true)][string]$JobPath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'progress.ps1')
try {
    Initialize-InstallerProgress $JobPath
    $job=Get-Content -LiteralPath $JobPath -Raw -Encoding UTF8|ConvertFrom-Json
    $script:installProgress.log=Join-Path $job.installRoot 'installation.log'
    Publish-InstallerProgress
    & (Join-Path $PSScriptRoot 'install.ps1') -InstallRoot $job.installRoot -ModelsRoot $job.modelsRoot -OllamaModelsRoot $job.ollamaModelsRoot -GuiJob $JobPath
    if($LASTEXITCODE -ne 0 -and (Get-Content -LiteralPath $script:progressFile -Raw|ConvertFrom-Json).state -eq 'running'){throw 'Installazione interrotta. Consultare il log per i dettagli.'}
} catch {
    if(Test-Path -LiteralPath $script:progressFile){$script:installProgress=Get-Content -LiteralPath $script:progressFile -Raw -Encoding UTF8|ConvertFrom-Json}
    Complete-InstallerProgress $false $_.Exception.Message
    Write-Error $_.Exception.Message -ErrorAction Continue
    exit 1
}
