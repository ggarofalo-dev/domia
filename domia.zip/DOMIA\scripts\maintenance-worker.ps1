param([Parameter(Mandatory=$true)][string]$JobFile)
$ErrorActionPreference = 'Stop'
$job = Get-Content -LiteralPath $JobFile -Raw -Encoding UTF8 | ConvertFrom-Json
$root = [IO.Path]::GetFullPath($job.root).TrimEnd('\')
$stage = [IO.Path]::GetFullPath($job.directory)
$moduleFolders=@('src','domiaLibs')+@(Get-ChildItem -LiteralPath $root -Directory -Filter '*Libs' -ErrorAction SilentlyContinue | Where-Object { !($_.Attributes -band [IO.FileAttributes]::ReparsePoint) } | Select-Object -ExpandProperty Name)
$hasServer=@($moduleFolders | Where-Object { Test-Path -LiteralPath (Join-Path $root ($_+'\server.mjs')) }).Count -gt 0
if (-not $stage.StartsWith($root + '\.maintenance\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid maintenance directory' }
if ($root -eq [IO.Path]::GetPathRoot($root) -or (-not $hasServer) -or ((Get-Item -LiteralPath $root).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Invalid DOMIA root' }
function Child-Path([string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if (-not $absolute.StartsWith($root + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside DOMIA' }
    return $absolute
}
function Result([string]$State,[string]$Message,[string]$Phase='') {
    @{id=$job.id;kind=$job.kind;state=$State;message=$Message;phase=$Phase;updated=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'result.json') -Encoding UTF8
}
function Remove-Tree([string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if ($absolute -ne $root -and -not $absolute.StartsWith($root + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Removal outside DOMIA' }
    $item = Get-Item -LiteralPath $absolute -Force
    # Unlink junctions without visiting the shared directory they point to.
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        if ($item.PSIsContainer) { [IO.Directory]::Delete($absolute) } else { Remove-Item -LiteralPath $absolute -Force }
        return
    }
    if ($item.PSIsContainer) { foreach ($child in Get-ChildItem -LiteralPath $absolute -Force) { Remove-Tree $child.FullName } }
    Remove-Item -LiteralPath $absolute -Force
}
function Stop-DOMIA {
    $status = Join-Path $root 'data\service\status.json'
    $supervisor = $null
    if (Test-Path -LiteralPath $status) {
        $state = Get-Content $status -Raw -Encoding UTF8 | ConvertFrom-Json
        $supervisor = $state.supervisorPid
        $owned = Get-CimInstance Win32_Process -Filter "ProcessId=$($state.appPid)" -ErrorAction SilentlyContinue
        if ($job.kind -ne 'stop' -and $owned -and $owned.ParentProcessId -eq $supervisor -and $owned.CommandLine -match '(?:src|[^/\\]+Libs)[/\\]server.mjs') { $job.appPid = $state.appPid }
    }
    if ($supervisor) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId=$supervisor"
        if ($process -and $process.CommandLine.Replace('/','\').Contains($root) -and $process.CommandLine -match 'watchdog.mjs') { Stop-Process -Id $supervisor -Force }
    }
    if ($job.kind -eq 'stop') {
        . (Join-Path $PSScriptRoot 'stop-engines.ps1')
        Result 'running' 'Arresto Ollama e i motori locali' 'engines'
        Stop-DomiaEngines -Root $root -OllamaUrl $job.ollamaUrl
    }
    $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($job.appPid)"
    if ($process -and $process.ExecutablePath -eq $job.nodePath -and $process.CommandLine -match '(?:src|[^/\\]+Libs)[/\\]server.mjs' -and ($process.CommandLine.Replace('/','\').Contains($root) -or $process.ParentProcessId -eq $supervisor)) { Stop-Process -Id $job.appPid -Force }
    Start-Sleep -Seconds 2
}
function Start-DOMIA {
    $arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $root 'scripts\run-background.ps1') + '"'
    Start-Process powershell.exe -ArgumentList $arguments -WindowStyle Hidden -WorkingDirectory $root
}
function Healthy {
    for ($i=0;$i -lt 40;$i++) {
        Start-Sleep -Seconds 2
        try { $health = Invoke-RestMethod ("http://127.0.0.1:$($job.port)/api/health") -TimeoutSec 2; if ($health.app -eq 'domia') { return $true } } catch {}
    }
    return $false
}
$rollback = Join-Path $stage 'rollback'
$changed = $false
$previousOllamaConfig = $null
$applied = @()
try {
    if ($job.kind -eq 'stop') {
        Result 'running' 'Arresto DOMIA' 'stop'
        # Allow the HTTP response to reach the administrator before stopping the server.
        Start-Sleep -Seconds 2
        Stop-DOMIA
        if (Get-Process -Id $job.appPid -ErrorAction SilentlyContinue) { throw 'Arresto non riuscito: processo DOMIA ancora attivo.' }
        Result 'done' 'DOMIA arrestato. Per riaprirlo usa il collegamento desktop.' 'stop'
        exit 0
    }
    Result 'running' 'Preparo e verifico le librerie del nuovo pacchetto' 'dependencies'
    if ($job.kind -eq 'update') {
        $nodeDirectory = Split-Path $job.nodePath
        $npm = Join-Path $nodeDirectory 'node_modules\npm\bin\npm-cli.js'
        if (-not (Test-Path -LiteralPath $npm)) { throw 'npm non trovato: ripetere installa.bat' }
        $reuseDependencies = $false
        if ((Test-Path -LiteralPath (Join-Path $root 'node_modules')) -and
            (Test-Path -LiteralPath (Join-Path $root 'package-lock.json')) -and
            (Get-FileHash -LiteralPath (Join-Path $root 'package-lock.json')).Hash -eq (Get-FileHash -LiteralPath (Join-Path $job.payload 'package-lock.json')).Hash) {
            $ErrorActionPreference = 'Continue'
            & $job.nodePath (Join-Path $root 'installer\verify-runtime.mjs') *> (Join-Path $stage 'verification-existing.log')
            $ErrorActionPreference = 'Stop'
            $reuseDependencies = $LASTEXITCODE -eq 0
        }
        Push-Location $job.payload
        try {
            $env:PATH = $nodeDirectory + ';' + $env:PATH
            if (-not $reuseDependencies) {
            $ErrorActionPreference = 'Continue'
            & $job.nodePath $npm ci --omit=dev --ignore-scripts --no-audit --no-fund --cache (Join-Path $root '.cache\npm') --registry=https://registry.npmjs.org/ --offline=false --prefer-online --fetch-retries=4 --fetch-timeout=120000 *> (Join-Path $stage 'dependencies.log')
            $ErrorActionPreference = 'Stop'
            if ($LASTEXITCODE -ne 0) { throw 'Download librerie fallito. Consultare dependencies.log.' }
            $ErrorActionPreference = 'Continue'
            & $job.nodePath (Join-Path $job.payload 'installer\verify-runtime.mjs') *> (Join-Path $stage 'verification.log')
            $ErrorActionPreference = 'Stop'
            if ($LASTEXITCODE -ne 0) { throw 'Verifica librerie fallita. Consultare verification.log.' }
            }
        } finally { Pop-Location }
    }
    Start-Sleep -Seconds 3
    if ($job.kind -eq 'uninstall') {
        $installConfig = Join-Path $root 'runtime\install.json'
        if ((Test-Path -LiteralPath $installConfig) -and (Get-NetFirewallRule -Name 'DOMIA Local - Private LAN' -ErrorAction SilentlyContinue)) {
            $helper = Join-Path $root 'installer\remove-system.ps1'
            $process = Start-Process powershell.exe -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$helper+'" -NodePath "'+$job.nodePath+'"') -Wait -PassThru -WindowStyle Hidden
            if ($process.ExitCode -ne 0) { throw 'Rimozione firewall non completata' }
        }
        Stop-DOMIA
        $shell = New-Object -ComObject WScript.Shell
        foreach ($folder in @([Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('Desktop'))) {
            $link = Join-Path $folder 'DOMIA.lnk'
            if (Test-Path -LiteralPath $link) { if ($shell.CreateShortcut($link).WorkingDirectory.TrimEnd('\') -eq $root) { Remove-Item -LiteralPath $link } }
        }
        $task = Get-ScheduledTask -TaskName 'DOMIA Local - Always On' -ErrorAction SilentlyContinue
        if ($task -and ($task.Actions.Arguments -join ' ').Contains($root)) { Unregister-ScheduledTask -TaskName $task.TaskName -Confirm:$false }
        if ($job.keepData) {
            $saved = Join-Path (Split-Path $root) ('DOMIA-dati-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
            if ([IO.Path]::GetFullPath((Split-Path $saved)) -ne [IO.Path]::GetFullPath((Split-Path $root))) { throw 'Invalid preservation path' }
            Move-Item -LiteralPath (Child-Path (Join-Path $root 'data')) -Destination $saved
        }
        # The root was explicitly authorized through the application's uninstall confirmation.
        if ($root -eq [IO.Path]::GetPathRoot($root) -or (-not $hasServer)) { throw 'Invalid uninstall root' }
        Set-Location $env:TEMP
        Remove-Tree $root
        exit 0
    }
    if ($job.kind -eq 'update') {
        $activeHealth = $null
        try { $activeHealth = Invoke-RestMethod ("http://127.0.0.1:$($job.port)/api/health") -TimeoutSec 2 } catch { }
        if ($activeHealth.busy -or $activeHealth.scheduled) { throw 'DOMIA sta elaborando richieste: aggiornamento annullato prima di modificare i file.' }
    }
    Result 'running' 'Aggiorno i file e conservo una copia della versione precedente' 'apply'
    Stop-DOMIA
    New-Item -ItemType Directory -Path $rollback -Force | Out-Null
    if ($job.kind -eq 'restore') {
        Move-Item -LiteralPath (Child-Path (Join-Path $root 'data')) -Destination (Join-Path $rollback 'data')
        $changed = $true
        Copy-Item -LiteralPath (Join-Path $job.payload 'data') -Destination $root -Recurse
    } elseif ($job.kind -eq 'update') {
        $changed = $true
        # Retire the legacy application directory, retaining it for rollback.
        if (Test-Path -LiteralPath (Join-Path $job.payload 'domiaLibs')) {
            foreach ($legacy in $moduleFolders | Select-Object -Unique) {
                if ($legacy -eq 'domiaLibs' -or !(Test-Path -LiteralPath (Join-Path $root ($legacy+'\server.mjs')))) { continue }
                Move-Item -LiteralPath (Child-Path (Join-Path $root $legacy)) -Destination (Join-Path $rollback $legacy)
            }
        }
        foreach ($name in @('src','domiaLibs','public','scripts','installer','package.json','package-lock.json','start.cmd','node_modules','config','installa.bat','Installa DOMIA.vbs','LEGGIMI.txt')) {
            if (-not (Test-Path -LiteralPath (Join-Path $job.payload $name))) { continue }
            if ($name -eq 'config' -and (Test-Path -LiteralPath (Join-Path $root 'config'))) { continue }
            $old = Child-Path (Join-Path $root $name)
            if (Test-Path -LiteralPath $old) { Move-Item -LiteralPath $old -Destination (Join-Path $rollback $name) }
            $applied += $name
            Copy-Item -LiteralPath (Join-Path $job.payload $name) -Destination $root -Recurse
        }
    } else { throw 'Operazione non valida' }
    if ($job.kind -eq 'update' -and (Test-Path -LiteralPath (Join-Path $root 'scripts\setup-ollama.mjs'))) {
        $localOllamaEndpoint = !$env:DOMIA_OLLAMA_URL -or $env:DOMIA_OLLAMA_URL.TrimEnd('/') -eq 'http://127.0.0.1:11435'
        if ($localOllamaEndpoint) {
            $ollamaNeedsUpdate = $true
            try { $installedOllamaVersion = Invoke-RestMethod 'http://127.0.0.1:11435/api/version' -TimeoutSec 3; if ([version]$installedOllamaVersion.version -ge [version]'0.40.13') { $ollamaNeedsUpdate = $false } } catch {}
            $ollamaConfigFile = Join-Path $root 'runtime\install.json'
            if (Test-Path -LiteralPath $ollamaConfigFile) {
                $previousOllamaConfig = Get-Content -LiteralPath $ollamaConfigFile -Raw -Encoding UTF8
                $previousOllamaPath = ($previousOllamaConfig | ConvertFrom-Json).ollamaPath
                if ($ollamaNeedsUpdate -and $previousOllamaPath -and (Test-Path -LiteralPath $previousOllamaPath)) {
                    . (Join-Path $root 'installer\ollama-processes.ps1')
                    Stop-InstallerOllama $previousOllamaPath
                }
            }
        }
        Result 'running' 'Preparo il runtime Ollama per i modelli audio' 'apply'
        & $job.nodePath (Join-Path $root 'scripts\setup-ollama.mjs') --if-installed
        if ($LASTEXITCODE -ne 0) { throw 'Aggiornamento Ollama fallito: ripristino della versione precedente.' }
    }
    Result 'running' 'Riavvio DOMIA e verifico la risposta del server' 'start'
    Start-DOMIA
    if ($job.kind -eq 'update' -and (Test-Path -LiteralPath (Join-Path $root 'scripts\setup-lfm-audio.mjs'))) {
        $voiceOutput = @(& $job.nodePath (Join-Path $root 'scripts\setup-lfm-audio.mjs') 2>&1)
        $voiceExitCode = $LASTEXITCODE
        $voiceOutput | Out-Host
        if ($voiceExitCode -ne 0) {
            $voiceDetail = (($voiceOutput | ForEach-Object { $_.ToString() }) -join ' ').Trim()
            if ($voiceDetail.Length -gt 1200) { $voiceDetail = $voiceDetail.Substring(0,1200) }
            throw ('Preparazione LFM3-Audio fallita (codice ' + $voiceExitCode + '): ' + $voiceDetail + '. Ripristinata la versione precedente di DOMIA.')
        }
    }
    if (-not (Healthy)) { throw 'La nuova installazione non risponde: ripristino automatico' }
    Result 'done' 'Operazione completata'
} catch {
    $message = $_.Exception.Message
    if ($null -ne $previousOllamaConfig) { Set-Content -LiteralPath (Join-Path $root 'runtime\install.json') -Value $previousOllamaConfig -Encoding UTF8 }
    if ($changed) {
        try {
            $health = Invoke-RestMethod ("http://127.0.0.1:$($job.port)/api/health") -TimeoutSec 2
            $job.appPid = $health.pid
        } catch {}
        try { Stop-DOMIA } catch {}
        foreach ($name in $applied) {
            $target = Child-Path (Join-Path $root $name)
            if (Test-Path -LiteralPath $target) { Remove-Tree $target }
        }
        foreach ($item in Get-ChildItem -LiteralPath $rollback) {
            $target = Child-Path (Join-Path $root $item.Name)
            if (Test-Path -LiteralPath $target) { Remove-Tree $target }
            Move-Item -LiteralPath $item.FullName -Destination $target
        }
        try { Start-DOMIA } catch {}
    }
    Result 'error' $message
    exit 1
}
