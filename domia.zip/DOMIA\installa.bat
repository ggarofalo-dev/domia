@echo off
setlocal
if exist "%~dp0Installa DOMIA.vbs" (
  start "" wscript.exe "%~dp0Installa DOMIA.vbs"
) else (
  start "" wscript.exe "%~dp0installer\Installa DOMIA.vbs"
)
exit /b 0
