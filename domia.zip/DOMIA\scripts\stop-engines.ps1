﻿# Stop only local engines belonging to this DOMIA installation/session.
function Get-DomiaEngineTargets([string]$Root,[string]$OllamaUrl,[object[]]$Processes,[int[]]$ListenerIds,[int]$SessionId,[string]$OllamaPath) {
    $base=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    $local=$false
    try { $endpoint=[uri]$OllamaUrl; $local=$endpoint.IsLoopback -and $endpoint.Scheme -in @('http','https') } catch {}
    $ollamaFiles=@()
    if($local -and $OllamaPath){$ollamaFiles+= [IO.Path]::GetFullPath($OllamaPath);$ollamaFiles+=Join-Path (Split-Path $OllamaPath) 'ollama app.exe'}
    if($local){foreach($item in $Processes){if($item.ProcessId -in $ListenerIds -and $item.Name -eq 'ollama.exe' -and $item.SessionId -eq $SessionId -and $item.ExecutablePath){$ollamaFiles+=$item.ExecutablePath;$ollamaFiles+=Join-Path (Split-Path $item.ExecutablePath) 'ollama app.exe'}}}
    foreach($item in $Processes){
        if($item.SessionId -ne $SessionId -or !$item.ExecutablePath){continue}
        $exe=$item.ExecutablePath
        $runtime=$exe.StartsWith($base+'runtime\',[StringComparison]::OrdinalIgnoreCase) -and $item.Name -notin @('node.exe','powershell.exe','pwsh.exe')
        $ffmpeg=$exe.Equals($base+'node_modules\@ffmpeg-installer\win32-x64\ffmpeg.exe',[StringComparison]::OrdinalIgnoreCase)
        $voice=$item.Name -in @('powershell.exe','pwsh.exe') -and $item.CommandLine -and $item.CommandLine.Replace('/','\').Contains($base+'scripts\speak-local.ps1')
        $ollama=$local -and $item.Name -eq 'ollama.exe' -and $item.ProcessId -in $ListenerIds -and $exe -in $ollamaFiles
        if($runtime -or $ffmpeg -or $voice -or $ollama){$item}
    }
}
function Stop-DomiaEngines([string]$Root,[string]$OllamaUrl) {
    $session=(Get-Process -Id $PID).SessionId
    $configFile=Join-Path $Root 'runtime\install.json';$ollamaPath=''
    if(Test-Path -LiteralPath $configFile){$config=Get-Content -LiteralPath $configFile -Raw -Encoding UTF8|ConvertFrom-Json;$ollamaPath=$config.ollamaPath}
    $port=0;try{$endpoint=[uri]$OllamaUrl;if($endpoint.IsLoopback){$port=$endpoint.Port}}catch{}
    for($attempt=0;$attempt -lt 5;$attempt++){
        $all=@(Get-CimInstance Win32_Process)
        $listeners=@();if($port -gt 0){$listeners=@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue|Select-Object -ExpandProperty OwningProcess -Unique)}
        $targets=@(Get-DomiaEngineTargets $Root $OllamaUrl $all $listeners $session $ollamaPath)
        if(!$targets.Count){return}
        # Close Ollama desktop first so it cannot restart the server.
        $targets=@($targets|Sort-Object @{Expression={if($_.Name -eq 'ollama app.exe'){0}else{1}}})
        function Stop-OwnedTree($target){
            $current=Get-CimInstance Win32_Process -Filter "ProcessId=$($target.ProcessId)" -ErrorAction SilentlyContinue
            if(!$current -or $current.CreationDate -ne $target.CreationDate -or $current.ExecutablePath -ne $target.ExecutablePath){return}
            foreach($child in @($all|Where-Object {$_.ParentProcessId -eq $target.ProcessId -and $_.CreationDate -ge $target.CreationDate -and $_.SessionId -eq $session})){Stop-OwnedTree $child}
            try { Stop-Process -Id $target.ProcessId -Force -ErrorAction Stop }
            catch { if(Get-CimInstance Win32_Process -Filter "ProcessId=$($target.ProcessId)" -ErrorAction SilentlyContinue){throw} }
        }
        foreach($target in $targets){Stop-OwnedTree $target}
        Start-Sleep -Milliseconds 500
    }
    throw 'Un motore locale continua a riavviarsi. Controlla altri servizi di avvio.'
}
