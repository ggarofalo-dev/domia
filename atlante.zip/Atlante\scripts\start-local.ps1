$projectRoot = Split-Path -Parent $PSScriptRoot
try {
    $health = Invoke-RestMethod 'http://127.0.0.1:3310/api/health' -TimeoutSec 3
    if ($health.app -eq 'atlante') { Write-Output 'Atlante e gia attivo: http://127.0.0.1:3310'; exit 0 }
} catch { }
Write-Output 'Avvio supervisore Atlante. Indirizzo: http://127.0.0.1:3310'
& (Join-Path $PSScriptRoot 'run-background.ps1')
