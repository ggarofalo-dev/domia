﻿function Get-AtlanteAutoStart([string]$Root,[string]$StartupFolder=[Environment]::GetFolderPath('Startup')) {
    $file=Join-Path $Root 'runtime\install.json'
    if(Test-Path -LiteralPath $file){
        $config=Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json
        if($null -ne $config.autoStart){return [bool]$config.autoStart}
    }
    $path=Join-Path $StartupFolder 'DOMIA.lnk'
    if(Test-Path -LiteralPath $path){
        $link=(New-Object -ComObject WScript.Shell).CreateShortcut($path)
        if($link.WorkingDirectory.TrimEnd('\') -eq [IO.Path]::GetFullPath($Root).TrimEnd('\')){return $true}
    }
    if(Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue){
        $task=Get-ScheduledTask -TaskName 'DOMIA Local - Always On' -ErrorAction SilentlyContinue
        $absolute=[IO.Path]::GetFullPath($Root).TrimEnd('\')
        if($task -and $task.State -ne 'Disabled' -and @($task.Actions|Where-Object {$_.Arguments -and $_.Arguments.Contains($absolute) -and $_.Arguments -match 'run-background.ps1'}).Count){return $true}
    }
    return $false
}
function Set-AtlanteStartup([string]$Root,[bool]$Enabled,[string]$StartupFolder=[Environment]::GetFolderPath('Startup'),[string]$DesktopFolder=[Environment]::GetFolderPath('Desktop'),[switch]$SkipScheduledTasks,[string]$NodePath='') {
    $Root=[IO.Path]::GetFullPath($Root).TrimEnd('\')
    $file=Join-Path $Root 'runtime\install.json'
    if(Test-Path -LiteralPath $file){$config=Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json}
    else{
        if(!$NodePath){$NodePath=(Get-Command node.exe -ErrorAction Stop).Source}
        $config=[pscustomobject]@{nodePath=$NodePath;ollamaPath=(Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe')}
        New-Item -ItemType Directory -Path (Split-Path -Parent $file) -Force|Out-Null
    }
    $shell=New-Object -ComObject WScript.Shell
    $path=Join-Path $StartupFolder 'DOMIA.lnk'
    if(Test-Path -LiteralPath $path){
        $link=$shell.CreateShortcut($path)
        if($link.WorkingDirectory.TrimEnd('\') -ne $Root){throw 'Collegamento di avvio DOMIA appartenente a un altra installazione.'}
    }
    # Ollama's desktop app creates its own login shortcut. Let DOMIA own engine startup.
    $ollamaLink=Join-Path $StartupFolder 'Ollama.lnk'
    if($false){
        $link=$shell.CreateShortcut($ollamaLink)
        if((Split-Path -Parent $link.TargetPath) -eq (Split-Path -Parent $config.ollamaPath)){
            $backup=Join-Path $Root 'runtime\startup-disabled'
            New-Item -ItemType Directory -Path $backup -Force|Out-Null
            Move-Item -LiteralPath $ollamaLink -Destination (Join-Path $backup 'Ollama.lnk') -Force
        }
    }
    # Remove the alternative DOMIA task only when it targets this installation.
    if(!$SkipScheduledTasks -and (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)){
        $task=Get-ScheduledTask -TaskName 'DOMIA Local - Always On' -ErrorAction SilentlyContinue
        if($task -and @($task.Actions|Where-Object {$_.Arguments -and $_.Arguments.Contains($Root) -and $_.Arguments -match 'run-background.ps1'}).Count){
            Disable-ScheduledTask -TaskName $task.TaskName|Out-Null
        }
    }
    if($Enabled){
        $link=$shell.CreateShortcut($path)
        $link.TargetPath="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        $link.Arguments='-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+(Join-Path $Root 'scripts\run-background.ps1')+'"'
        $link.WorkingDirectory=$Root;$link.WindowStyle=7;$link.Save()
    }elseif(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}
    $link=$shell.CreateShortcut((Join-Path $DesktopFolder 'DOMIA.lnk'))
    $link.TargetPath="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $link.Arguments='-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+(Join-Path $Root 'installer\open.ps1')+'"'
    $link.WorkingDirectory=$Root;$link.WindowStyle=7;$link.Save()
    $config|Add-Member -NotePropertyName autoStart -NotePropertyValue $Enabled -Force
    $temp=$file+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    [IO.File]::WriteAllText($temp,($config|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    if(Test-Path -LiteralPath $file){[IO.File]::Replace($temp,$file,[NullString]::Value)}else{[IO.File]::Move($temp,$file)}
}
