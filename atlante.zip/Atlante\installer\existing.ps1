﻿function Get-ExistingAtlante([string]$Root) {
    if(!$Root -or (!(Test-Path -LiteralPath (Join-Path $Root 'src\server.mjs')) -and !(Test-Path -LiteralPath (Join-Path $Root 'atlanteLibs\server.mjs'))) -or !(Test-Path -LiteralPath (Join-Path $Root 'package.json'))){return $null}
    if(!(Test-Path -LiteralPath (Join-Path $Root 'runtime\install.json')) -and !(Test-Path -LiteralPath (Join-Path $Root 'data\auth.sqlite'))){return $null}
    $package=Get-Content -LiteralPath (Join-Path $Root 'package.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if($package.name -ne 'atlante-local'){return $null}
    return @{root=[IO.Path]::GetFullPath($Root).TrimEnd('\');version=$package.version}
}
function Find-ExistingAtlante([string]$DefaultRoot) {
    $candidates=@()
    $registered=Get-ItemProperty -LiteralPath 'HKCU:\Software\DOMIA' -ErrorAction SilentlyContinue
    if($registered.InstallRoot){$candidates+=$registered.InstallRoot}
    $candidates+=$DefaultRoot
    $shell=New-Object -ComObject WScript.Shell
    foreach($folder in @([Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('Desktop'))){
        $link=Join-Path $folder 'DOMIA.lnk'
        if(Test-Path -LiteralPath $link){$candidates+=$shell.CreateShortcut($link).WorkingDirectory}
    }
    foreach($candidate in $candidates){$installed=Get-ExistingAtlante $candidate;if($installed){return $installed}}
    return $null
}
function Register-AtlanteInstallation([string]$Root) {
    New-Item -Path 'HKCU:\Software\DOMIA' -Force|Out-Null
    Set-ItemProperty -LiteralPath 'HKCU:\Software\DOMIA' -Name 'InstallRoot' -Value ([IO.Path]::GetFullPath($Root))
}
