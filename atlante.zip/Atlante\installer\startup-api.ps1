﻿param([Parameter(Mandatory=$true)][string]$Root,[ValidateSet('status','manual','automatic')][string]$Mode='status',[string]$NodePath='')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'startup.ps1')
try{
    if($Mode -ne 'status'){Set-AtlanteStartup -Root $Root -Enabled ($Mode -eq 'automatic') -NodePath $NodePath}
    @{supported=$true;autoStart=(Get-AtlanteAutoStart $Root);windowsUser=[Environment]::UserName}|ConvertTo-Json -Compress
}catch{
    @{error=$_.Exception.Message}|ConvertTo-Json -Compress
    exit 1
}
