﻿. (Join-Path $PSScriptRoot 'progress.ps1')
. (Join-Path $PSScriptRoot 'existing.ps1')
. (Join-Path $PSScriptRoot 'startup.ps1')
function New-InstallerWindow([string]$InstallRoot) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $ui=@{rows=@{};browse=@{};running=$false;worker=$null;jobPath='';logPath='';lastState=$null;started=$false}
    $form=[Windows.Forms.Form]::new();$ui.form=$form
    $form.Text='Installa DOMIA';$form.Size=[Drawing.Size]::new(820,860);$form.MinimumSize=[Drawing.Size]::new(620,620)
    $form.StartPosition='CenterScreen';$form.Font=[Drawing.Font]::new('Segoe UI',10);$form.AutoScaleMode='Dpi';$form.BackColor=[Drawing.Color]::FromArgb(11,16,32);$form.ForeColor=[Drawing.Color]::FromArgb(237,242,250)
    $layout=[Windows.Forms.TableLayoutPanel]::new();$layout.Dock='Fill';$layout.Padding=[Windows.Forms.Padding]::new(22);$layout.ColumnCount=1;$layout.RowCount=7
    [void]$layout.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Percent',100))
    foreach($height in @('AutoSize','AutoSize','AutoSize','AutoSize','AutoSize','Percent','AutoSize')){[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::$height, $(if($height -eq 'Percent'){100}else{0})))}
    $title=[Windows.Forms.Label]::new();$ui.title=$title;$title.Text='Prepariamo DOMIA sul tuo PC';$title.Font=[Drawing.Font]::new('Segoe UI',18,[Drawing.FontStyle]::Bold);$title.AutoSize=$true;$title.Margin=[Windows.Forms.Padding]::new(0,0,0,12)
    $intro=[Windows.Forms.Label]::new();$ui.intro=$intro;$intro.Text='Scegli le cartelle, la modalità di avvio e premi Installa. I download possono richiedere diversi GB. Le barre animate indicano una fase senza percentuale disponibile.';$intro.AutoSize=$true;$intro.Dock='Fill';$intro.Margin=[Windows.Forms.Padding]::new(0,0,0,14)
    $folders=[Windows.Forms.TableLayoutPanel]::new();$folders.ColumnCount=3;$folders.RowCount=4;$folders.AutoSize=$true;$folders.Dock='Fill'
    [void]$folders.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Absolute',200));[void]$folders.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Percent',100));[void]$folders.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Absolute',88))
    $defaults=@{installRoot=$InstallRoot;modelsRoot=(Join-Path $InstallRoot 'models');ollamaModelsRoot=(Join-Path $InstallRoot 'models-ollama')}
    $file=Join-Path $InstallRoot 'data\model-folders.json'
    if(Test-Path -LiteralPath $file){$saved=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json;if($saved.local){$defaults.modelsRoot=$saved.local};if($saved.ollama){$defaults.ollamaModelsRoot=$saved.ollama}}
    $index=0
    foreach($entry in @(@('installRoot','Applicazione DOMIA'),@('modelsRoot','Immagini, audio, video e OCR'),@('ollamaModelsRoot','Modelli Ollama'))){
        $key=$entry[0];$label=[Windows.Forms.Label]::new();$label.Text=$entry[1];$label.AutoSize=$true;$label.Anchor='Left';$label.Margin=[Windows.Forms.Padding]::new(0,8,6,8)
        $input=[Windows.Forms.TextBox]::new();$input.Name=$key;$input.Text=$defaults[$key];$input.Dock='Fill';$input.Margin=[Windows.Forms.Padding]::new(0,4,8,8);$ui[$key]=$input
        $browse=[Windows.Forms.Button]::new();$ui.browse[$key]=$browse;$browse.Text='Sfoglia';$browse.Dock='Fill';$browse.Margin=[Windows.Forms.Padding]::new(0,3,0,8)
        $browse.Add_Click({$picker=[Windows.Forms.FolderBrowserDialog]::new();$picker.Description='Scegli una cartella sul PC';$picker.SelectedPath=$input.Text;try{if($picker.ShowDialog($form) -eq 'OK'){$input.Text=$picker.SelectedPath}}finally{$picker.Dispose()}}.GetNewClosure())
        $folders.Controls.Add($label,0,$index);$folders.Controls.Add($input,1,$index);$folders.Controls.Add($browse,2,$index);$index++
    }
    $ui.folders=$folders
    $autoStart=[Windows.Forms.CheckBox]::new();$ui.autoStart=$autoStart;$autoStart.AutoSize=$true;$autoStart.Dock='Fill';$autoStart.Text='Avvia DOMIA automaticamente quando accedo a Windows';$autoStart.Margin=[Windows.Forms.Padding]::new(0,8,0,8)
    $folders.Controls.Add($autoStart,0,3);$folders.SetColumnSpan($autoStart,3)
    $note=[Windows.Forms.Label]::new();$ui.note=$note;$note.Text='I modelli già scaricati restano nella vecchia cartella. Per riutilizzarli copiali nella nuova destinazione mantenendo le sottocartelle.';$note.AutoSize=$true;$note.Dock='Fill';$note.Margin=[Windows.Forms.Padding]::new(0,8,0,12)
    $status=[Windows.Forms.Label]::new();$ui.status=$status;$status.Text='Pronto per iniziare';$status.AutoSize=$true;$status.Dock='Fill';$status.Margin=[Windows.Forms.Padding]::new(0,0,0,12)
    $scroll=[Windows.Forms.Panel]::new();$scroll.Dock='Fill';$scroll.AutoScroll=$true;$scroll.BackColor=[Drawing.Color]::White;$ui.scroll=$scroll
    $list=[Windows.Forms.TableLayoutPanel]::new();$ui.list=$list;$list.Dock='Top';$list.AutoSize=$true;$list.ColumnCount=3;$list.Padding=[Windows.Forms.Padding]::new(12)
    [void]$list.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Percent',47));[void]$list.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Percent',20));[void]$list.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new('Percent',33))
    $scroll.Controls.Add($list)
    $actions=[Windows.Forms.FlowLayoutPanel]::new();$actions.Dock='Fill';$actions.AutoSize=$true;$actions.FlowDirection='RightToLeft';$actions.Padding=[Windows.Forms.Padding]::new(0,14,0,0)
    foreach($entry in @(@('start','Installa'),@('close','Annulla'),@('log','Apri log'))){$button=[Windows.Forms.Button]::new();$button.Text=$entry[1];$button.Size=[Drawing.Size]::new(130,42);$ui[$entry[0]]=$button;$actions.Controls.Add($button)}
    $ui.log.Enabled=$false;$ui.start.BackColor=[Drawing.Color]::FromArgb(59,130,246)
    $layout.Controls.Add($title,0,0);$layout.Controls.Add($intro,0,1);$layout.Controls.Add($folders,0,2);$layout.Controls.Add($note,0,3);$layout.Controls.Add($status,0,4);$layout.Controls.Add($scroll,0,5);$layout.Controls.Add($actions,0,6);$form.Controls.Add($layout)
    function Set-DomiaColors($control){foreach($child in $control.Controls){$child.ForeColor=[Drawing.Color]::FromArgb(237,242,250);$child.BackColor=[Drawing.Color]::FromArgb(16,27,45);if($child -is [Windows.Forms.TextBox]){$child.BackColor=[Drawing.Color]::FromArgb(22,34,55)};if($child -is [Windows.Forms.Button]){$child.FlatStyle='Flat';$child.BackColor=[Drawing.Color]::FromArgb(27,48,78)};Set-DomiaColors $child}}
    Set-DomiaColors $form;$ui.start.BackColor=[Drawing.Color]::FromArgb(59,130,246)
    $resize={
        $width=[Math]::Max(300,$form.ClientSize.Width-56)
        foreach($text in @($title,$intro,$note,$status)){$text.MaximumSize=[Drawing.Size]::new($width,0)}
        $list.MaximumSize=[Drawing.Size]::new([Math]::Max(300,$width-[Windows.Forms.SystemInformation]::VerticalScrollBarWidth),0)
        $list.Width=$list.MaximumSize.Width
    }.GetNewClosure()
    $form.Add_Resize($resize);& $resize
    Set-InstallerWindowMode $ui
    $windowHelpers=Join-Path $PSScriptRoot 'gui-window.ps1'
    $ui.installRoot.Add_TextChanged({try{. $windowHelpers;Set-InstallerWindowMode $ui}catch{$ui.status.Text=$_.Exception.Message}}.GetNewClosure())
    return $ui
}

function Set-InstallerWindowRows($Ui,[string]$Mode) {
    $Ui.mode=$Mode;$list=$Ui.list
    foreach($control in @($list.Controls)){$control.Dispose()}
    $list.Controls.Clear();$list.RowStyles.Clear();$Ui.rows.Clear();$index=0
    foreach($entry in (Get-InstallerStepDefinitions $Mode)){
        [void]$list.RowStyles.Add([Windows.Forms.RowStyle]::new('Absolute',52));$label=[Windows.Forms.Label]::new();$label.Text=$entry[1];$label.Dock='Fill';$label.TextAlign='MiddleLeft'
        $state=[Windows.Forms.Label]::new();$state.Text='In attesa';$state.Dock='Fill';$state.TextAlign='MiddleLeft';$state.ForeColor=[Drawing.Color]::DimGray
        $bar=[Windows.Forms.ProgressBar]::new();$bar.Dock='Fill';$bar.Margin=[Windows.Forms.Padding]::new(4,15,4,15)
        $list.Controls.Add($label,0,$index);$list.Controls.Add($state,1,$index);$list.Controls.Add($bar,2,$index);$Ui.rows[$entry[0]]=@{label=$label;state=$state;bar=$bar};$index++
    }
    $list.RowCount=$index
}
function Set-InstallerWindowMode($Ui) {
    $existing=Get-ExistingAtlante $Ui.installRoot.Text
    $mode=if($existing){'update'}else{'install'}
    if($Ui.mode -ne $mode){Set-InstallerWindowRows $Ui $mode}
    $Ui.existing=$existing
    $root=$Ui.installRoot.Text
    if(!$root){return}
    if($Ui.startupRoot -ne $root){$Ui.autoStart.Checked=Get-AtlanteAutoStart $root;$Ui.startupRoot=$root}
    $local=Join-Path $root 'models';$ollama=Join-Path $root 'models-ollama'
    $savedFile=Join-Path $root 'data\model-folders.json'
    if(Test-Path -LiteralPath $savedFile){$saved=Get-Content -LiteralPath $savedFile -Raw|ConvertFrom-Json;if($saved.local){$local=$saved.local};if($saved.ollama){$ollama=$saved.ollama}}
    $Ui.modelsRoot.Text=$local;$Ui.ollamaModelsRoot.Text=$ollama
    foreach($key in @('modelsRoot','ollamaModelsRoot')){$Ui[$key].Enabled=!$existing;$Ui.browse[$key].Enabled=!$existing}
    if($existing){
        $Ui.form.Text='Aggiorna DOMIA';$Ui.title.Text='Aggiorniamo DOMIA sul tuo PC';$Ui.start.Text='Aggiorna'
        $Ui.intro.Text='Installazione trovata: versione '+$existing.version+'. Applico i file del pacchetto corrente e verifico il riavvio.'
        $Ui.note.Text='Conversazioni, utenti, impostazioni e modelli vengono conservati. Puoi cambiare la scelta di avvio; le cartelle restano quelle salvate.'
    }else{
        $Ui.form.Text='Installa DOMIA';$Ui.title.Text='Prepariamo DOMIA sul tuo PC';$Ui.start.Text='Installa'
        $Ui.intro.Text='Scegli le cartelle, la modalità di avvio e premi Installa. I download possono richiedere diversi GB. Le barre animate indicano una fase senza percentuale disponibile.'
        $Ui.note.Text='I modelli gia scaricati restano nella vecchia cartella. Per riutilizzarli copiali nella nuova destinazione mantenendo le sottocartelle.'
    }
}
function Update-InstallerWindow($Ui,$State) {
    if($State.mode -and $State.mode -ne $Ui.mode){Set-InstallerWindowRows $Ui $State.mode}
    $previousStep=$Ui.lastState.current
    $Ui.lastState=$State;$Ui.status.Text=$State.message
    foreach($step in $State.steps){
        $row=$Ui.rows[$step.id];if(!$row){continue};$percent=$step.percent
        if($step.state -eq 'running' -and $State.download -and $State.totalBytes -gt 0 -and (Test-Path -LiteralPath $State.download)){$length=(Get-Item -LiteralPath $State.download).Length;$percent=[Math]::Min(100,[int](100*$length/$State.totalBytes));$Ui.status.Text=$State.message+' · '+[Math]::Round($length/1GB,2)+' / '+[Math]::Round($State.totalBytes/1GB,2)+' GB'}
        switch($step.state){
            'done'{$row.state.Text='Completato';$row.bar.Style='Continuous';$row.bar.Value=100;$row.state.ForeColor=[Drawing.Color]::DarkGreen}
            'running'{$row.state.ForeColor=[Drawing.Color]::DarkGreen;if($null -eq $percent){$row.state.Text='In corso';$row.bar.Style='Marquee';$row.bar.MarqueeAnimationSpeed=30}else{$row.state.Text="$percent%";$row.bar.Style='Continuous';$row.bar.Value=[Math]::Max(0,[Math]::Min(100,[int]$percent))}}
            'error'{$row.state.Text='Da verificare';$row.state.ForeColor=[Drawing.Color]::Firebrick;$row.bar.Style='Continuous';$row.bar.Value=0}
            default{$row.state.Text='In attesa';$row.bar.Style='Continuous';$row.bar.Value=0}
        }
    }
    if($State.current -and $State.current -ne $previousStep -and $Ui.rows[$State.current]){$Ui.scroll.ScrollControlIntoView($Ui.rows[$State.current].label)}
    $Ui.logPath=$State.log;$Ui.log.Enabled=!!($State.log -and (Test-Path -LiteralPath $State.log))
    if($State.state -in @('done','error')){$Ui.running=$false;$Ui.close.Enabled=$true;$Ui.close.Text='Chiudi';$Ui.start.Enabled=$false;$Ui.status.ForeColor=if($State.state -eq 'done'){[Drawing.Color]::DarkGreen}else{[Drawing.Color]::Firebrick}}
}
